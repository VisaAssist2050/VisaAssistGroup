import React from 'react';
import CountryTabContent from '@/components/countries/CountryTabContent';
import CountryRequirements from '@/components/countries/CountryRequirements';
import CountrySuccessTips from '@/components/countries/CountrySuccessTips';

const UkContent = () => {
  const visaTypes = [
    { name: "Student Route Visa", description: "For students enrolled in a UK educational institution" },
    { name: "Short-term Study Visa", description: "For courses lasting up to 6 months (or 11 months for English language courses)" },
    { name: "Graduate Route Visa", description: "For post-study work opportunities after graduation" },
  ];

  const requirements = {
    title: "UK Student Visa Requirements",
    documentation: [
      "Confirmation of Acceptance for Studies (CAS) from your institution",
      "Valid passport",
      "Proof of English language proficiency (IELTS, TOEFL)",
      "Tuberculosis test results (if applicable)",
      "Biometric information",
    ],
    financial: [
      "Proof of funds for tuition fees and living expenses",
      "Bank statements (funds must be held for at least 28 days)",
      "Proof of payment of tuition fees (if applicable)",
    ],
    additional: [
      "Academic qualifications mentioned in your CAS",
      "Immigration Health Surcharge payment",
    ],
  };

  const successTips = {
    title: "UK Student Visa Success Tips",
    categories: [
      {
        title: "Application Preparation",
        tips: [
          "Apply early (up to 3 months before course start)",
          "Double-check all information on your CAS",
          "Ensure financial documents meet exact requirements",
          "Translate all documents into English",
        ],
      },
      {
        title: "Credibility Interview",
        tips: [
          "Research your course and institution thoroughly",
          "Be clear about your career plans",
          "Explain how the course relates to your previous studies",
          "Demonstrate intention to return home after studies",
        ],
      },
      {
        title: "Post-Approval Steps",
        tips: [
          "Check your visa details for accuracy",
          "Register with police (if required)",
          "Collect your Biometric Residence Permit",
          "Understand your work rights and restrictions",
        ],
      },
    ],
  };

  return (
    <>
      <CountryTabContent
        imageSrc="https://images.unsplash.com/photo-1518340097318-f6add4b6f6d2"
        imageAlt="UK university campus"
        title="Study in the United Kingdom"
        description="The UK is home to some of the world's oldest and most prestigious universities. With a rich academic tradition, diverse cultural experience, and shorter degree programs, the UK offers an excellent environment for international students."
        visaTypes={visaTypes}
        consultationButtonText="Get UK Visa Consultation"
        onConsultationClick={() => console.log("UK Consultation Clicked")}
      />
      <CountryRequirements {...requirements} />
      <CountrySuccessTips {...successTips} />
    </>
  );
};

export default UkContent;