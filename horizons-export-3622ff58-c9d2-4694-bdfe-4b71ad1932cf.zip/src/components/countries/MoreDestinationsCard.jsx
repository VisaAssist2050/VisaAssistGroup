import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6 }
  }
};

const MoreDestinationsCard = ({
  imageSrc,
  imageAlt,
  title,
  description,
  features,
  onLearnMoreClick
}) => {
  return (
    <motion.div variants={fadeIn}>
      <Card className="country-card h-full overflow-hidden">
        <div className="h-48 overflow-hidden">
          <img 
            className="w-full h-full object-cover"
            alt={imageAlt}
           src="https://images.unsplash.com/photo-1675270714610-11a5cadcc7b3" />
        </div>
        <CardHeader>
          <CardTitle>{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 mb-4">{description}</p>
          <ul className="space-y-1 mb-4">
            {features.map((feature, index) => (
              <li key={index} className="flex items-start">
                <CheckCircle className="h-4 w-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full" onClick={onLearnMoreClick}>
            Learn More
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default MoreDestinationsCard;