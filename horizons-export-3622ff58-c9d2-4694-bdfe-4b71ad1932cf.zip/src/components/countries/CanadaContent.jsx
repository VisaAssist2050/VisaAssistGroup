import React from 'react';
import CountryTabContent from '@/components/countries/CountryTabContent';
import CountryRequirements from '@/components/countries/CountryRequirements';
import CountrySuccessTips from '@/components/countries/CountrySuccessTips';

const CanadaContent = () => {
  const visaTypes = [
    { name: "Study Permit", description: "Required for courses longer than 6 months" },
    { name: "Student Direct Stream (SDS)", description: "Expedited processing for eligible countries" },
    { name: "Post-Graduation Work Permit (PGWP)", description: "Work in Canada after graduation for up to 3 years" },
  ];

  const requirements = {
    title: "Canada Study Permit Requirements",
    documentation: [
      "Letter of Acceptance from a Designated Learning Institution (DLI)",
      "Valid passport",
      "Proof of English/French language proficiency",
      "Immigration medical examination results",
      "Biometrics (photo and fingerprints)",
    ],
    financial: [
      "Proof of funds for tuition fees, living expenses, and return transportation",
      "Bank statements or proof of a Canadian bank account",
      "Guaranteed Investment Certificate (GIC) of $10,000 CAD (for SDS)",
    ],
    additional: [
      "Statement of purpose/study plan",
      "Police certificates (if applicable)",
    ],
  };

  const successTips = {
    title: "Canada Study Permit Success Tips",
    categories: [
      {
        title: "Application Strategy",
        tips: [
          "Consider applying through the Student Direct Stream if eligible",
          "Apply at least 3 months before your program starts",
          "Ensure your DLI is on the approved list",
          "Create a comprehensive study plan",
        ],
      },
      {
        title: "Financial Documentation",
        tips: [
          "Show funds available for at least one year of studies",
          "Provide consistent and clear financial history",
          "Explain any large deposits clearly",
          "Include proof of tuition payment if made",
        ],
      },
      {
        title: "Demonstrating Ties",
        tips: [
          "Show strong ties to your home country",
          "Explain how Canadian education fits your career plan",
          "Demonstrate intention to return after studies",
          "Include a clear post-graduation plan",
        ],
      },
    ],
  };

  return (
    <>
      <CountryTabContent
        imageSrc="https://images.unsplash.com/photo-1677730277400-097e5da58a56"
        imageAlt="Canadian university campus"
        title="Study in Canada"
        description="Canada offers high-quality education with a pathway to permanent residency. With its welcoming environment, diverse culture, and excellent post-graduation work opportunities, Canada is an increasingly popular destination for international students."
        visaTypes={visaTypes}
        consultationButtonText="Get Canada Visa Consultation"
        onConsultationClick={() => console.log("Canada Consultation Clicked")}
      />
      <CountryRequirements {...requirements} />
      <CountrySuccessTips {...successTips} />
    </>
  );
};

export default CanadaContent;