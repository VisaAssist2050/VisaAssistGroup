import React from 'react';
import CountryTabContent from '@/components/countries/CountryTabContent';
import CountryRequirements from '@/components/countries/CountryRequirements';
import CountrySuccessTips from '@/components/countries/CountrySuccessTips';

const UsaContent = () => {
  const visaTypes = [
    { name: "F-1 Student Visa", description: "For full-time academic students at accredited institutions" },
    { name: "J-1 Exchange Visitor Visa", description: "For exchange programs, research scholars, and certain students" },
    { name: "M-1 Vocational Student Visa", description: "For vocational or non-academic programs" },
  ];

  const requirements = {
    title: "USA Visa Requirements",
    documentation: [
      "Form I-20 from your educational institution",
      "DS-160 Online Nonimmigrant Visa Application",
      "Valid passport (valid for at least 6 months beyond your stay)",
      "SEVIS fee payment receipt",
      "Visa application fee payment receipt",
    ],
    financial: [
      "Bank statements showing sufficient funds for tuition and living expenses",
      "Sponsorship letters (if applicable)",
      "Scholarship award letters (if applicable)",
    ],
    additional: [
      "Academic transcripts and diplomas",
      "Standardized test scores (TOEFL, SAT, GRE, GMAT)",
    ],
  };

  const successTips = {
    title: "USA Student Visa Success Tips",
    categories: [
      {
        title: "Before the Interview",
        tips: [
          "Research your program thoroughly",
          "Prepare clear reasons for choosing your institution",
          "Organize all documents in a logical order",
          "Practice common interview questions",
        ],
      },
      {
        title: "During the Interview",
        tips: [
          "Dress professionally and arrive early",
          "Speak clearly and confidently",
          "Demonstrate strong ties to your home country",
          "Be concise in your answers",
        ],
      },
      {
        title: "Common Pitfalls to Avoid",
        tips: [
          "Inconsistent information across documents",
          "Unclear post-graduation plans",
          "Insufficient financial documentation",
          "Memorized or rehearsed-sounding answers",
        ],
      },
    ],
  };

  return (
    <>
      <CountryTabContent
        imageSrc="https://images.unsplash.com/photo-1472121779802-43c68a9f405f"
        imageAlt="USA university campus"
        title="Study in the United States"
        description="The United States hosts the largest number of international students in the world, offering world-class education across thousands of institutions. With diverse programs, cutting-edge research facilities, and extensive networking opportunities, the US remains a top choice for international education."
        visaTypes={visaTypes}
        consultationButtonText="Get USA Visa Consultation"
        onConsultationClick={() => console.log("USA Consultation Clicked")}
      />
      <CountryRequirements {...requirements} />
      <CountrySuccessTips {...successTips} />
    </>
  );
};

export default UsaContent;