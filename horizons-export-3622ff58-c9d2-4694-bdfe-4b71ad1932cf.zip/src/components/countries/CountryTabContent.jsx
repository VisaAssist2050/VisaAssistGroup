import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CountryTabContent = ({
  imageSrc,
  imageAlt,
  title,
  description,
  visaTypes,
  onConsultationClick,
  consultationButtonText
}) => {
  return (
    <div className="grid md:grid-cols-2 gap-12 items-center mb-12">
      <motion.div
        initial={{ opacity: 0, x: -30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        <img 
          className="rounded-lg shadow-lg w-full"
          alt={imageAlt}
         src="https://images.unsplash.com/photo-1697256200022-f61abccad430" />
      </motion.div>
      <motion.div
        initial={{ opacity: 0, x: 30 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        <h2 className="text-3xl font-bold mb-4">{title}</h2>
        <p className="text-gray-600 mb-6">{description}</p>
        <div className="space-y-4 mb-6">
          {visaTypes.map((visa, index) => (
            <div key={index} className="flex items-start">
              <CheckCircle className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold">{visa.name}</h3>
                <p className="text-gray-600">{visa.description}</p>
              </div>
            </div>
          ))}
        </div>
        <Button onClick={onConsultationClick}>{consultationButtonText}</Button>
      </motion.div>
    </div>
  );
};

export default CountryTabContent;