import React from 'react';
import { motion } from 'framer-motion';
import MoreDestinationsCard from '@/components/countries/MoreDestinationsCard';

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6 }
  }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
      delayChildren: 0.2,
    }
  }
};

const destinations = [
  {
    imageSrc: "https://images.unsplash.com/photo-1686829613628-3e4ebe6f27e7",
    imageAlt: "New Zealand landscape with university",
    title: "New Zealand",
    description: "New Zealand offers world-class education in a stunning natural environment. With its high quality of life, friendly locals, and post-study work opportunities, it's an excellent choice for international students.",
    features: ["Student Visa for full-time studies", "Post-study work visa options"],
  },
  {
    imageSrc: "https://images.unsplash.com/photo-1600143000960-ee67ecb9857f",
    imageAlt: "Singapore skyline with university",
    title: "Singapore",
    description: "Singapore is a global education hub with world-class universities. Its strategic location, multicultural environment, and strong economy make it an attractive destination for international students.",
    features: ["Student's Pass for full-time studies", "Work opportunities during and after studies"],
  },
  {
    imageSrc: "https://images.unsplash.com/photo-1544388064-39f0da581609",
    imageAlt: "Ireland landscape with university",
    title: "Ireland",
    description: "Ireland offers high-quality education with a friendly, English-speaking environment. With its strong ties to industry, vibrant culture, and post-study work opportunities, Ireland is gaining popularity among international students.",
    features: ["Study Visa for non-EU/EEA students", "Third Level Graduate Scheme for post-study work"],
  },
  {
    imageSrc: "https://images.unsplash.com/photo-1682358279672-5c7a027d635e",
    imageAlt: "Netherlands university and canals",
    title: "Netherlands",
    description: "The Netherlands offers numerous English-taught programs at affordable tuition rates. With its innovative education system, international environment, and excellent quality of life, it's a popular choice for international students.",
    features: ["MVV (entry visa) and residence permit", "Orientation Year permit for graduates"],
  },
  {
    imageSrc: "https://images.unsplash.com/photo-1579877649586-eb4bea21ffb5",
    imageAlt: "Sweden university campus",
    title: "Sweden",
    description: "Sweden is known for its innovative education system and research excellence. With its focus on sustainability, equality, and student independence, Sweden offers a unique educational experience.",
    features: ["Residence permit for studies", "Work during studies and 6-month job-seeking period after graduation"],
  },
  {
    imageSrc: "https://images.unsplash.com/photo-1694978417313-5cc891e8aba0",
    imageAlt: "Japan university campus",
    title: "Japan",
    description: "Japan offers a unique blend of traditional culture and cutting-edge technology. With its high-quality education, safe environment, and increasing number of English-taught programs, Japan is attracting more international students.",
    features: ["Student Visa for full-time studies", "Part-time work permission during studies"],
  },
];

const MoreDestinationsSection = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16"
          variants={fadeIn}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">More Study Destinations</h2>
          <p className="text-lg text-gray-600">
            Explore other popular countries for international education.
          </p>
        </motion.div>

        <motion.div
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.1 }}
        >
          {destinations.map((dest, index) => (
            <MoreDestinationsCard
              key={index}
              {...dest}
              onLearnMoreClick={() => console.log(`Learn more about ${dest.title}`)}
            />
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default MoreDestinationsSection;