import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const TipCategory = ({ title, tips }) => (
  <div className="bg-white p-6 rounded-lg shadow-sm">
    <h4 className="font-semibold text-lg mb-2">{title}</h4>
    <ul className="space-y-2">
      {tips.map((tip, index) => (
        <li key={index} className="flex items-start">
          <ArrowRight className="h-5 w-5 text-primary mr-2 mt-0.5 flex-shrink-0" />
          <span>{tip}</span>
        </li>
      ))}
    </ul>
  </div>
);

const CountrySuccessTips = ({ title, categories }) => {
  return (
    <motion.div 
      className="bg-primary/5 rounded-lg p-8"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <h3 className="text-2xl font-bold mb-4">{title}</h3>
      <div className="grid md:grid-cols-3 gap-6">
        {categories.map((category, index) => (
          <TipCategory key={index} title={category.title} tips={category.tips} />
        ))}
      </div>
    </motion.div>
  );
};

export default CountrySuccessTips;