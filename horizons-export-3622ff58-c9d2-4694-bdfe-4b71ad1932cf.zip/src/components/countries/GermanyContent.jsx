import React from 'react';
import CountryTabContent from '@/components/countries/CountryTabContent';
import CountryRequirements from '@/components/countries/CountryRequirements';
import CountrySuccessTips from '@/components/countries/CountrySuccessTips';

const GermanyContent = () => {
  const visaTypes = [
    { name: "Student Visa", description: "For non-EU students studying in Germany" },
    { name: "Language Course Visa", description: "For intensive German language courses" },
    { name: "Job Seeker Visa", description: "For graduates seeking employment after studies" },
  ];

  const requirements = {
    title: "Germany Student Visa Requirements",
    documentation: [
      "Letter of admission from a German university",
      "Valid passport",
      "Proof of German language skills or English for English-taught programs",
      "Health insurance coverage",
      "Biometric photographs",
    ],
    financial: [
      "Proof of financial resources (approximately €10,332 per year)",
      "Blocked account (Sperrkonto) at a German bank",
      "Scholarship award letter (if applicable)",
    ],
    additional: [
      "Academic certificates and transcripts",
      "Motivation letter/statement of purpose",
    ],
  };

  const successTips = {
    title: "Germany Student Visa Success Tips",
    categories: [
      {
        title: "Application Preparation",
        tips: [
          "Apply at least 3 months before your course starts",
          "Schedule an appointment at the German embassy/consulate",
          "Prepare all documents in German or English",
          "Make copies of all documents",
        ],
      },
      {
        title: "Blocked Account",
        tips: [
          "Open a blocked account with a German bank",
          "Deposit the required amount (€10,332)",
          "Obtain the blocked account confirmation",
          "Understand monthly withdrawal limits",
        ],
      },
      {
        title: "Interview Preparation",
        tips: [
          "Research your program and university thoroughly",
          "Be clear about your study and career goals",
          "Demonstrate basic knowledge of German culture",
          "Show intention to return to your home country",
        ],
      },
    ],
  };

  return (
    <>
      <CountryTabContent
        imageSrc="https://images.unsplash.com/photo-1507592504747-fcd5cb5535ff"
        imageAlt="German university campus"
        title="Study in Germany"
        description="Germany offers world-class education with low or no tuition fees at public universities. With its strong economy, excellent research opportunities, and central European location, Germany is an attractive destination for international students."
        visaTypes={visaTypes}
        consultationButtonText="Get Germany Visa Consultation"
        onConsultationClick={() => console.log("Germany Consultation Clicked")}
      />
      <CountryRequirements {...requirements} />
      <CountrySuccessTips {...successTips} />
    </>
  );
};

export default GermanyContent;