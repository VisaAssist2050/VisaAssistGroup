import React from 'react';
import CountryTabContent from '@/components/countries/CountryTabContent';
import CountryRequirements from '@/components/countries/CountryRequirements';
import CountrySuccessTips from '@/components/countries/CountrySuccessTips';

const FranceContent = () => {
  const visaTypes = [
    { name: "Long-Stay Student Visa", description: "For studies longer than 90 days" },
    { name: "Short-Stay Student Visa", description: "For studies less than 90 days" },
    { name: "Talent Passport", description: "For graduates seeking employment in France" },
  ];

  const requirements = {
    title: "France Student Visa Requirements",
    documentation: [
      "Acceptance letter from a French institution",
      "Valid passport",
      "Proof of French language proficiency (or English for English-taught programs)",
      "Campus France approval (for certain countries)",
      "Passport-sized photographs",
    ],
    financial: [
      "Proof of financial resources (approximately €615 per month)",
      "Bank statements or scholarship award letters",
      "Proof of accommodation in France",
    ],
    additional: [
      "Academic certificates and transcripts",
      "Motivation letter",
      "Return ticket or proof of funds for return journey",
    ],
  };

  const successTips = {
    title: "France Student Visa Success Tips",
    categories: [
      {
        title: "Campus France Procedure",
        tips: [
          "Register on the Campus France platform",
          "Complete the online application form",
          "Pay the Campus France fee",
          "Attend the Campus France interview if required",
        ],
      },
      {
        title: "Visa Application",
        tips: [
          "Apply at least 3 months before your course starts",
          "Schedule an appointment at the French consulate",
          "Prepare all documents in French or with translations",
          "Pay the visa application fee",
        ],
      },
      {
        title: "After Arrival",
        tips: [
          "Validate your visa within 3 months of arrival",
          "Register with OFII (French Immigration Office)",
          "Open a French bank account",
          "Apply for housing assistance (CAF) if eligible",
        ],
      },
    ],
  };

  return (
    <>
      <CountryTabContent
        imageSrc="https://images.unsplash.com/photo-1687210096916-cad33c3c3899"
        imageAlt="French university campus"
        title="Study in France"
        description="France offers high-quality education with relatively low tuition fees at public universities. With its rich cultural heritage, central European location, and excellent research opportunities, France attracts thousands of international students each year."
        visaTypes={visaTypes}
        consultationButtonText="Get France Visa Consultation"
        onConsultationClick={() => console.log("France Consultation Clicked")}
      />
      <CountryRequirements {...requirements} />
      <CountrySuccessTips {...successTips} />
    </>
  );
};

export default FranceContent;