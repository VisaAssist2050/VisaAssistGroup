import React from 'react';
import CountryTabContent from '@/components/countries/CountryTabContent';
import CountryRequirements from '@/components/countries/CountryRequirements';
import CountrySuccessTips from '@/components/countries/CountrySuccessTips';

const AustraliaContent = () => {
  const visaTypes = [
    { name: "Student Visa (Subclass 500)", description: "For all levels of study in Australia" },
    { name: "Temporary Graduate Visa (Subclass 485)", description: "For post-study work opportunities" },
    { name: "Student Guardian Visa (Subclass 590)", description: "For guardians of younger students" },
  ];

  const requirements = {
    title: "Australia Student Visa Requirements",
    documentation: [
      "Confirmation of Enrollment (CoE) from your institution",
      "Valid passport",
      "Genuine Temporary Entrant (GTE) statement",
      "English language proficiency (IELTS, TOEFL, etc.)",
      "Health insurance (Overseas Student Health Cover)",
    ],
    financial: [
      "Proof of funds for tuition, living expenses, and travel",
      "Bank statements or financial sponsorship documents",
      "Evidence of financial capacity (approximately AUD 21,041 per year)",
    ],
    additional: [
      "Academic transcripts and qualifications",
      "Character and health assessments",
    ],
  };

  const successTips = {
    title: "Australia Student Visa Success Tips",
    categories: [
      {
        title: "GTE Statement",
        tips: [
          "Write a compelling personal statement",
          "Explain your course choice clearly",
          "Connect your studies to career goals",
          "Address any gaps in study or employment",
        ],
      },
      {
        title: "Application Process",
        tips: [
          "Apply online through ImmiAccount",
          "Submit all documents in the required format",
          "Pay the visa application fee",
          "Complete health examinations if required",
        ],
      },
      {
        title: "Post-Approval Planning",
        tips: [
          "Arrange accommodation in advance",
          "Understand work rights (40 hours per fortnight)",
          "Research Australian culture and lifestyle",
          "Plan for orientation and enrollment",
        ],
      },
    ],
  };

  return (
    <>
      <CountryTabContent
        imageSrc="https://images.unsplash.com/photo-1686829613628-3e4ebe6f27e7"
        imageAlt="Australian university campus"
        title="Study in Australia"
        description="Australia is known for its excellent education system, high quality of life, and stunning natural environment. With globally recognized qualifications and post-study work opportunities, Australia offers a compelling destination for international students."
        visaTypes={visaTypes}
        consultationButtonText="Get Australia Visa Consultation"
        onConsultationClick={() => console.log("Australia Consultation Clicked")}
      />
      <CountryRequirements {...requirements} />
      <CountrySuccessTips {...successTips} />
    </>
  );
};

export default AustraliaContent;