
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Globe, 
  FileText, 
  CheckCircle, 
  MessageSquare, 
  Briefcase, 
  Home, 
  GraduationCap, 
  Plane,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6 }
  }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

const ServicesPage = () => {
  return (
    <div className="pt-32 pb-20">
      {/* Hero Section */}
      <section className="pb-20">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            className="text-center max-w-3xl mx-auto mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Comprehensive Visa Services</h1>
            <p className="text-lg text-gray-600">
              From initial assessment to post-arrival support, we provide end-to-end assistance for your international education journey.
            </p>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
          >
            <motion.div variants={fadeIn}>
              <Card className="service-card h-full">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                    <Globe className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Visa Assessment</CardTitle>
                  <CardDescription>Evaluating your eligibility for student visas</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Our comprehensive assessment evaluates your academic background, financial situation, and personal circumstances to determine your eligibility for student visas in different countries.
                  </p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Personalized country recommendations</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Detailed eligibility analysis</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Success probability estimation</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeIn}>
              <Card className="service-card h-full">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                    <FileText className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Application Preparation</CardTitle>
                  <CardDescription>Comprehensive documentation assistance</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    We help you prepare and organize all required documents for your visa application, ensuring they meet the specific requirements of your destination country.
                  </p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Document checklist and verification</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Application form completion</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Financial documentation guidance</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeIn}>
              <Card className="service-card h-full">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                    <MessageSquare className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Interview Coaching</CardTitle>
                  <CardDescription>Preparation for visa interviews</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Our interview coaching sessions prepare you for visa interviews with mock interviews, common questions, and personalized feedback to boost your confidence.
                  </p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Mock interview sessions</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Country-specific question preparation</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Non-verbal communication training</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeIn}>
              <Card className="service-card h-full">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                    <Briefcase className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Post-Study Work Guidance</CardTitle>
                  <CardDescription>Planning for career opportunities abroad</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    We provide guidance on post-study work opportunities in your destination country, including visa extensions, work permits, and potential pathways to permanent residency.
                  </p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Work visa requirements analysis</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Immigration pathway planning</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Timeline and eligibility assessment</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeIn}>
              <Card className="service-card h-full">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                    <Home className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Accommodation Assistance</CardTitle>
                  <CardDescription>Finding suitable housing options</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    We help you find and secure suitable accommodation options near your educational institution, considering your budget, preferences, and safety requirements.
                  </p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>On-campus housing application support</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Off-campus housing recommendations</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Lease agreement review</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div variants={fadeIn}>
              <Card className="service-card h-full">
                <CardHeader>
                  <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                    <Plane className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle>Pre-Departure Orientation</CardTitle>
                  <CardDescription>Preparing for your journey abroad</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Our pre-departure orientation sessions prepare you for life in your destination country, covering cultural adjustment, practical tips, and essential information.
                  </p>
                  <ul className="mt-4 space-y-2">
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Cultural adaptation guidance</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Practical living tips and resources</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>Health insurance and safety information</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            className="text-center max-w-3xl mx-auto mb-16"
            variants={fadeIn}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Visa Consulting Process</h2>
            <p className="text-lg text-gray-600">
              We follow a structured approach to ensure the highest chance of success for your visa application.
            </p>
          </motion.div>

          <div className="relative">
            {/* Process Timeline */}
            <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-primary/20"></div>

            <motion.div 
              className="space-y-12 relative"
              variants={staggerContainer}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.1 }}
            >
              <motion.div 
                variants={fadeIn}
                className="flex flex-col md:flex-row items-center"
              >
                <div className="md:w-1/2 md:pr-12 md:text-right">
                  <h3 className="text-2xl font-bold text-primary mb-2">Initial Consultation</h3>
                  <p className="text-gray-600">
                    We begin with a comprehensive assessment of your academic background, career goals, and personal circumstances to understand your needs and preferences.
                  </p>
                </div>
                <div className="mt-4 md:mt-0 md:w-1/2 md:pl-12 flex justify-start">
                  <div className="bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold z-10">1</div>
                </div>
              </motion.div>

              <motion.div 
                variants={fadeIn}
                className="flex flex-col md:flex-row-reverse items-center"
              >
                <div className="md:w-1/2 md:pl-12">
                  <h3 className="text-2xl font-bold text-primary mb-2">Country and Program Selection</h3>
                  <p className="text-gray-600">
                    Based on your profile, we recommend suitable countries and educational programs that align with your goals and maximize your chances of visa approval.
                  </p>
                </div>
                <div className="mt-4 md:mt-0 md:w-1/2 md:pr-12 flex justify-end">
                  <div className="bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold z-10">2</div>
                </div>
              </motion.div>

              <motion.div 
                variants={fadeIn}
                className="flex flex-col md:flex-row items-center"
              >
                <div className="md:w-1/2 md:pr-12 md:text-right">
                  <h3 className="text-2xl font-bold text-primary mb-2">Documentation Preparation</h3>
                  <p className="text-gray-600">
                    We guide you through the process of gathering and preparing all required documents, ensuring they meet the specific requirements of your destination country.
                  </p>
                </div>
                <div className="mt-4 md:mt-0 md:w-1/2 md:pl-12 flex justify-start">
                  <div className="bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold z-10">3</div>
                </div>
              </motion.div>

              <motion.div 
                variants={fadeIn}
                className="flex flex-col md:flex-row-reverse items-center"
              >
                <div className="md:w-1/2 md:pl-12">
                  <h3 className="text-2xl font-bold text-primary mb-2">Application Submission</h3>
                  <p className="text-gray-600">
                    We assist you with completing and submitting your visa application, ensuring all forms are correctly filled out and all supporting documents are properly organized.
                  </p>
                </div>
                <div className="mt-4 md:mt-0 md:w-1/2 md:pr-12 flex justify-end">
                  <div className="bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold z-10">4</div>
                </div>
              </motion.div>

              <motion.div 
                variants={fadeIn}
                className="flex flex-col md:flex-row items-center"
              >
                <div className="md:w-1/2 md:pr-12 md:text-right">
                  <h3 className="text-2xl font-bold text-primary mb-2">Interview Preparation</h3>
                  <p className="text-gray-600">
                    We conduct mock interviews and provide comprehensive coaching to prepare you for your visa interview, focusing on common questions and potential challenges.
                  </p>
                </div>
                <div className="mt-4 md:mt-0 md:w-1/2 md:pl-12 flex justify-start">
                  <div className="bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold z-10">5</div>
                </div>
              </motion.div>

              <motion.div 
                variants={fadeIn}
                className="flex flex-col md:flex-row-reverse items-center"
              >
                <div className="md:w-1/2 md:pl-12">
                  <h3 className="text-2xl font-bold text-primary mb-2">Post-Approval Support</h3>
                  <p className="text-gray-600">
                    After your visa is approved, we provide pre-departure orientation and ongoing support to help you prepare for your journey and adjust to life in your new country.
                  </p>
                </div>
                <div className="mt-4 md:mt-0 md:w-1/2 md:pr-12 flex justify-end">
                  <div className="bg-primary text-white rounded-full w-12 h-12 flex items-center justify-center text-xl font-bold z-10">6</div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            className="text-center max-w-3xl mx-auto mb-16"
            variants={fadeIn}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-lg text-gray-600">
              Find answers to common questions about our visa consulting services.
            </p>
          </motion.div>

          <motion.div 
            className="max-w-3xl mx-auto"
            variants={fadeIn}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger className="text-lg font-medium">
                  How long does the student visa process typically take?
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  The processing time varies by country, ranging from 2 weeks to 3 months. We recommend starting the process at least 3-6 months before your intended start date to allow for any unexpected delays. Our consultants will provide you with a detailed timeline based on your specific destination country.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2">
                <AccordionTrigger className="text-lg font-medium">
                  What documents are typically required for a student visa?
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  Common requirements include acceptance letters from educational institutions, proof of financial support, academic transcripts, language proficiency test results, passport, photographs, and a completed visa application form. Additional documents may be required depending on the country. Our consultants will provide you with a comprehensive checklist tailored to your destination.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3">
                <AccordionTrigger className="text-lg font-medium">
                  How do you improve the chances of visa approval?
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  We improve approval chances by ensuring all documentation is complete and properly presented, preparing you thoroughly for interviews, addressing potential red flags in your application, and leveraging our experience with specific embassy requirements. Our 98% success rate is based on our meticulous attention to detail and understanding of visa requirements.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4">
                <AccordionTrigger className="text-lg font-medium">
                  What happens if my visa application is rejected?
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  If your application is rejected, we conduct a thorough analysis of the rejection reasons and develop a strategy for reapplication. This may involve strengthening certain aspects of your application, providing additional documentation, or considering alternative countries or programs. Our experience with handling rejections allows us to address issues effectively in subsequent applications.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5">
                <AccordionTrigger className="text-lg font-medium">
                  Can I work while studying abroad?
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  Work permissions vary by country. Many student visas allow part-time work during the academic year and full-time work during breaks. For example, the US allows up to 20 hours per week on-campus, Canada allows up to 20 hours off-campus, and Australia allows up to 40 hours per fortnight. We provide detailed information about work rights for your specific destination country.
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-6">
                <AccordionTrigger className="text-lg font-medium">
                  Do you provide assistance with scholarship applications?
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  Yes, we provide guidance on scholarship opportunities and assist with scholarship applications. This includes identifying suitable scholarships, reviewing application materials, and helping you prepare compelling personal statements and essays. Our goal is to help you secure financial support to make your international education more affordable.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Start Your Visa Application?</h2>
            <p className="text-xl mb-8">
              Book a free consultation with our expert visa advisors and take the first step toward your international education.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                Book Free Consultation
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                <Link to="/contact">Contact Us</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default ServicesPage;
