
import React from 'react';
import { motion } from 'framer-motion';
import { Users, Award, Clock, Globe, BookOpen, GraduationCap } from 'lucide-react';
import { Button } from '@/components/ui/button';

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6 }
  }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

const AboutPage = () => {
  return (
    <div className="pt-32 pb-20">
      {/* Hero Section */}
      <section className="pb-16">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            className="text-center max-w-3xl mx-auto mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About GlobalVisa</h1>
            <p className="text-lg text-gray-600">
              We are dedicated to helping students achieve their international education dreams through expert visa consulting services.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <p className="text-gray-600 mb-4">
                GlobalVisa was founded in 2008 by a team of education consultants who recognized the challenges international students face when navigating the complex visa application process.
              </p>
              <p className="text-gray-600 mb-4">
                What began as a small consulting firm has grown into a trusted partner for thousands of students worldwide. Our mission has remained the same: to simplify the visa application process and help students achieve their international education goals.
              </p>
              <p className="text-gray-600 mb-4">
                Over the past 15 years, we have helped more than 5,000 students successfully obtain student visas for countries across the globe, with a remarkable 98% success rate. Our team has expanded to include visa specialists with expertise in various countries and education systems.
              </p>
              <p className="text-gray-600">
                Today, GlobalVisa is recognized as a leader in student visa consulting, known for our personalized approach, attention to detail, and commitment to student success.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <img  
                className="rounded-lg shadow-xl w-full" 
                alt="GlobalVisa team in office"
               src="https://images.unsplash.com/photo-1581656702382-9ae90e68e7b7" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our Values Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            className="text-center max-w-3xl mx-auto mb-16"
            variants={fadeIn}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Values</h2>
            <p className="text-lg text-gray-600">
              These core principles guide our approach to student visa consulting.
            </p>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.1 }}
          >
            <motion.div variants={fadeIn} className="bg-gray-50 rounded-lg p-8 shadow-sm">
              <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Student-Centered Approach</h3>
              <p className="text-gray-600">
                We put students at the center of everything we do, tailoring our services to meet their unique needs and circumstances. We believe in building relationships based on trust, transparency, and open communication.
              </p>
            </motion.div>

            <motion.div variants={fadeIn} className="bg-gray-50 rounded-lg p-8 shadow-sm">
              <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <Award className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Excellence</h3>
              <p className="text-gray-600">
                We strive for excellence in all aspects of our service, from the accuracy of our advice to the thoroughness of our application preparation. Our high success rate reflects our commitment to quality and attention to detail.
              </p>
            </motion.div>

            <motion.div variants={fadeIn} className="bg-gray-50 rounded-lg p-8 shadow-sm">
              <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <Globe className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Global Perspective</h3>
              <p className="text-gray-600">
                Our team brings a global perspective to student visa consulting, with expertise in education systems and immigration policies across multiple countries. We stay updated on the latest changes to provide accurate advice.
              </p>
            </motion.div>

            <motion.div variants={fadeIn} className="bg-gray-50 rounded-lg p-8 shadow-sm">
              <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <BookOpen className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Continuous Learning</h3>
              <p className="text-gray-600">
                We are committed to continuous learning and professional development. Our consultants regularly update their knowledge of visa regulations, education systems, and best practices to provide the most current advice.
              </p>
            </motion.div>

            <motion.div variants={fadeIn} className="bg-gray-50 rounded-lg p-8 shadow-sm">
              <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Timeliness</h3>
              <p className="text-gray-600">
                We understand the importance of timing in the visa application process. We work efficiently to meet deadlines and ensure that applications are submitted with ample time for processing, reducing stress for our students.
              </p>
            </motion.div>

            <motion.div variants={fadeIn} className="bg-gray-50 rounded-lg p-8 shadow-sm">
              <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                <GraduationCap className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Student Success</h3>
              <p className="text-gray-600">
                We measure our success by the success of our students. We are committed to helping students not just obtain their visas, but also prepare for a successful educational experience abroad through comprehensive support.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            className="text-center max-w-3xl mx-auto mb-16"
            variants={fadeIn}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Expert Team</h2>
            <p className="text-lg text-gray-600">
              Meet our dedicated team of visa specialists who will guide you through your journey.
            </p>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.1 }}
          >
            <motion.div variants={fadeIn} className="text-center">
              <div className="mb-4 relative mx-auto w-48 h-48 overflow-hidden rounded-full">
                <img  
                  className="w-full h-full object-cover" 
                  alt="Sarah Johnson - Founder & CEO"
                 src="https://images.unsplash.com/photo-1592878863518-0357779ebc6a" />
              </div>
              <h3 className="text-xl font-bold">Sarah Johnson</h3>
              <p className="text-primary font-medium mb-2">Founder & CEO</p>
              <p className="text-gray-600 text-sm">
                Former international student advisor with 20+ years of experience in education consulting.
              </p>
            </motion.div>

            <motion.div variants={fadeIn} className="text-center">
              <div className="mb-4 relative mx-auto w-48 h-48 overflow-hidden rounded-full">
                <img  
                  className="w-full h-full object-cover" 
                  alt="David Chen - Head of US Visa Services"
                 src="https://images.unsplash.com/photo-1700227047786-8835486ba7af" />
              </div>
              <h3 className="text-xl font-bold">David Chen</h3>
              <p className="text-primary font-medium mb-2">Head of US Visa Services</p>
              <p className="text-gray-600 text-sm">
                Specialist in US immigration with previous experience at a top US university's international office.
              </p>
            </motion.div>

            <motion.div variants={fadeIn} className="text-center">
              <div className="mb-4 relative mx-auto w-48 h-48 overflow-hidden rounded-full">
                <img  
                  className="w-full h-full object-cover" 
                  alt="Priya Sharma - UK & Europe Specialist"
                 src="https://images.unsplash.com/photo-1544212408-c711b7c19b92" />
              </div>
              <h3 className="text-xl font-bold">Priya Sharma</h3>
              <p className="text-primary font-medium mb-2">UK & Europe Specialist</p>
              <p className="text-gray-600 text-sm">
                Expert in UK and European education systems with a background in international education policy.
              </p>
            </motion.div>

            <motion.div variants={fadeIn} className="text-center">
              <div className="mb-4 relative mx-auto w-48 h-48 overflow-hidden rounded-full">
                <img  
                  className="w-full h-full object-cover" 
                  alt="Michael Okafor - Australia & Canada Specialist"
                 src="https://images.unsplash.com/photo-1592878863518-0357779ebc6a" />
              </div>
              <h3 className="text-xl font-bold">Michael Okafor</h3>
              <p className="text-primary font-medium mb-2">Australia & Canada Specialist</p>
              <p className="text-gray-600 text-sm">
                Former immigration consultant with extensive experience in Australian and Canadian visa processes.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            className="text-center max-w-3xl mx-auto mb-16"
            variants={fadeIn}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Achievements</h2>
            <p className="text-lg text-gray-600">
              We take pride in our track record of helping students achieve their international education goals.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <div className="flex items-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mr-6">
                  <span className="text-2xl font-bold text-primary">5K+</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Successful Visa Applications</h3>
                  <p className="text-gray-600">
                    We've helped over 5,000 students secure visas for their international education.
                  </p>
                </div>
              </div>

              <div className="flex items-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mr-6">
                  <span className="text-2xl font-bold text-primary">98%</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Success Rate</h3>
                  <p className="text-gray-600">
                    Our visa applications have a 98% approval rate, significantly higher than the industry average.
                  </p>
                </div>
              </div>

              <div className="flex items-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mr-6">
                  <span className="text-2xl font-bold text-primary">50+</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Countries Covered</h3>
                  <p className="text-gray-600">
                    We provide visa consulting services for over 50 countries worldwide.
                  </p>
                </div>
              </div>

              <div className="flex items-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mr-6">
                  <span className="text-2xl font-bold text-primary">15+</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Years of Experience</h3>
                  <p className="text-gray-600">
                    With over 15 years in the industry, we bring extensive expertise to every application.
                  </p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <img  
                className="rounded-lg shadow-xl w-full" 
                alt="GlobalVisa achievements"
               src="https://images.unsplash.com/photo-1581656702382-9ae90e68e7b7" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <motion.div 
            className="text-center max-w-3xl mx-auto mb-16"
            variants={fadeIn}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Clients Say</h2>
            <p className="text-lg text-gray-600">
              Hear from students who successfully achieved their study abroad dreams with our help.
            </p>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-3 gap-8"
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.1 }}
          >
            <motion.div variants={fadeIn} className="bg-white p-8 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="mr-4">
                  <img  
                    className="h-12 w-12 rounded-full object-cover" 
                    alt="Student testimonial"
                   src="https://images.unsplash.com/photo-1559388965-3b93297d3450" />
                </div>
                <div>
                  <h4 className="font-semibold">Ahmed Hassan</h4>
                  <p className="text-sm text-gray-500">Studying at MIT, USA</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "I was overwhelmed by the US visa process until I found GlobalVisa. Their step-by-step guidance and interview preparation made all the difference. I'm now pursuing my dream of studying computer science at MIT!"
              </p>
            </motion.div>

            <motion.div variants={fadeIn} className="bg-white p-8 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="mr-4">
                  <img  
                    className="h-12 w-12 rounded-full object-cover" 
                    alt="Student testimonial"
                   src="https://images.unsplash.com/photo-1581726690015-c9861fa5057f" />
                </div>
                <div>
                  <h4 className="font-semibold">Maria Rodriguez</h4>
                  <p className="text-sm text-gray-500">Studying at University of Sydney, Australia</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "After my first Australian visa application was rejected, I turned to GlobalVisa for help. Their expertise in addressing the previous issues was remarkable. My second application was approved, and I'm now pursuing my Master's degree!"
              </p>
            </motion.div>

            <motion.div variants={fadeIn} className="bg-white p-8 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="mr-4">
                  <img  
                    className="h-12 w-12 rounded-full object-cover" 
                    alt="Student testimonial"
                   src="https://images.unsplash.com/photo-1687274775832-a58db13fbf7f" />
                </div>
                <div>
                  <h4 className="font-semibold">Li Wei</h4>
                  <p className="text-sm text-gray-500">Studying at University of Toronto, Canada</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "GlobalVisa's knowledge of the Canadian student visa process is exceptional. They helped me navigate the Student Direct Stream application with ease, and I received my approval in just 3 weeks. I highly recommend their services!"
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Begin Your Study Abroad Journey?</h2>
            <p className="text-xl mb-8">
              Get a free consultation with our expert visa advisors and take the first step toward your international education.
            </p>
            <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
              Book Your Free Consultation
            </Button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;
